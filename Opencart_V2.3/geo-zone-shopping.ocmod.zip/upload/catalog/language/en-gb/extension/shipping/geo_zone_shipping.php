<?php
// Text
$_['text_title']				= 'Geo Zone Shipping';